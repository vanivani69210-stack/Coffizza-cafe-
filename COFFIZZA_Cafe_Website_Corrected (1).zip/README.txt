# COFFIZZA Café Website

A single-file responsive static website for COFFIZZA Café.

## Files
- `index.html` — complete website (HTML + CSS)

## Free hosting
This site can be published as a static website on GitHub Pages or Cloudflare Pages.

No backend, database, API keys, or paid Emergent hosting are required.

## Important
The website uses the business information supplied for COFFIZZA Café. No rating, reviews, menu prices, or other unverified business claims are included.
